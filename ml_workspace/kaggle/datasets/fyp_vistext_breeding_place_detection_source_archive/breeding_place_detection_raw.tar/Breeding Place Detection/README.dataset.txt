# Mosquito Beeding Place > Mosquito Possible Bradding Site
https://universe.roboflow.com/adnans-workspace/mosquito-beeding-place

Provided by a Roboflow user
License: CC BY 4.0

